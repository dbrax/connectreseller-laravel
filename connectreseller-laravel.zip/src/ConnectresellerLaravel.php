<?php

namespace Epmnzava\ConnectresellerLaravel;

class ConnectresellerLaravel
{
    // Build your next great package.
}
